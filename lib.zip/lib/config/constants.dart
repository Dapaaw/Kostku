class AppConstants {
  static const String baseUrl = 'http://127.0.0.1:8000/api'; 
  static const double defaultPadding = 16.0;
}
